echo "TODO: explain find command"
echo "use find . -name bankinfo to get the place you need to go next"