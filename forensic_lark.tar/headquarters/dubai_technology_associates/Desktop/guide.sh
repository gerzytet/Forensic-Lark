echo "This doesn't seem to have anything useful in it..."
echo "Think about what directory name might contain information we could use to ${bold}reverse the fraudulent transactions${norm}"
