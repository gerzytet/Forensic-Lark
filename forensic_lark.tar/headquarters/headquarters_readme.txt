Welcome to headquarters!
Among other things, this is where the inner workings of commands like hq and hint are kept!
While we appreciate your visit, we really need you out there investigating.
Please use:
cd $AGENT_DIR
to get back to your assignment.
