# Name of game: Forensic-Lark

Developed by: Craig White and Michael LaRusso

# Narative: You are a rookie forensic computer analyist starting your new job at the Miami Police Cybercrime Division
You were told that they have been understaffed for months and they are happy to have you in their ranks
They already have a few jobs for you to get started with but they want to see if your up to the task

# Getting started:
To get started, use `source init.sh` and read the console for further instructions.
Some areas have hints.  use `hint` to see the hint, if there is one.  We don't have an in-game tutorial for this yet.

# Resetting:
To reset progress, investigation files, or both, run the reset.sh script for instructions.