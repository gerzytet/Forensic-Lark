for i in "$(find)"
do
	touch $i/a.empty
done
