#!/bin/bash
echo "Hey you can't just run every script you see"
echo "it could be a virus for all you know"
#On the other hand if your just looking inside, then thats a good practice 
