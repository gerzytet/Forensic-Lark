echo "You aren't in the right place!"
temp=${lock_loc/\/hqlock/}
echo "Use cd ${temp/headquarters/agent} to get back"
