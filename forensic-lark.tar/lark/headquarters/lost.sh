echo "Our systems cannot detect where you are"
echo "Did you navigate to directory outside the game?  you can use cd \$AGENT_DIR to get back."
echo "Did you rename a directory?  You must never do this!  Remember: tampering with evidence is forbidden.  Rename it back, then try again. If you are unable to get the directory back to its orginal form then we will need to reset."
echo "Did you create a new directory, then navigate into it?  You must go back to the original directory to use the hq command."