#!/bin/bash
echo "Welcome to dubai technology associates main directory, you know what to do."
