#!/bin/bash
echo "There are plenty of directories to search through but the documents directory is looking the most suspicious"
