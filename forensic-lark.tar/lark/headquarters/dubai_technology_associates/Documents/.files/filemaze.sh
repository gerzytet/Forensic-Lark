echo "The scammers have made themselves quite a maze of files in here!"
echo "If you're lost, go back to the .files directory and run ${hili}hq${norm} or ${hili}hint${norm} from there"