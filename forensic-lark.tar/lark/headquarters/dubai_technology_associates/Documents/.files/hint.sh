echo "Use the command:"
echo "find -name *bank*"
echo "Then go into the directory you found"
