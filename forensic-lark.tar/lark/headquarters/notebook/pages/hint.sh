#!/bin/bash
echo "${bold}hint${norm}"
echo "The hint command is special command useful for our operations, incase the agent ever feels as if they are stuck they can type in this command to get a hint on what to do next."