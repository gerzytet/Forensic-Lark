#!/bin/bash
echo "${bold}hq${norm}"
echo "The most important command that allows hq to contact the agent, this also allows the agent to send data to hq if the agent is able to find any important informaiton that needs scanning."