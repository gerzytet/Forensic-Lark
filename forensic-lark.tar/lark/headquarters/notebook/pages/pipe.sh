#!/bin/bash
echo "${bold}| (Pipes)${norm}"
echo "The pipe is a very useful tool that allows the user to pass on the results of the previous grep into the next command, pipes can also be strung allowing the user to use several commands in a single line of text."
