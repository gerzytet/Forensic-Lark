#!/bin/bash
echo "${bold}ls -a${norm}"
echo "A extention off of the ls command that allows you to view all files including the hidden ones within the directory its called in."