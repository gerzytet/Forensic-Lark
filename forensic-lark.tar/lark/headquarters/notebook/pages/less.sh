#!/bin/bash
echo "${bold}less${norm}"
echo "  The less command allows you to read the contents of files like cat but unlike cat, less shows the text in a user friendly format."
echo "  To traverse the contents you can use the up and down arrow keys to go line by line and the left and right arrow keys to go page by page"