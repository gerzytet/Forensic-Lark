#!/bin/bash
echo "${bold}grep${norm}"
echo "The grep command allows you to search through a file for specific words you wish to look for, it then prints out the line the word is on."
