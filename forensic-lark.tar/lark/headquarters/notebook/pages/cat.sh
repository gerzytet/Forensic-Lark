#!/bin/bash
echo "${bold}cat${norm}"
echo "  The cat command allows the user to read the contents of files, not all files can be read."