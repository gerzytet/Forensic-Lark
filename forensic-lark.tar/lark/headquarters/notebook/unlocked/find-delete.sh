#!/bin/bash
echo "${bold}find -delete${norm}"
echo "	The find command allows you to find any file in a directory, tacking on the -delete to the end of it allows you to delete any of the files the find command finds"
echo "The syntax is as follows, find (filter) -delete"
